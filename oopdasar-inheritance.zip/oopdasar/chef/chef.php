<?php 

class Chef {

	public $nama = "nama",
		   $alamat = "alamat",
		   $tinggi = "tinggi",
		   $usia = "usia",
		   $tugas = "tugas";

	public function namaChef() {
		return "$this->nama";
	}

	public function alamatChef() {
		return "$this->alamat";
	}

	public function tinggiChef() {
		return "$this->tinggi";
	}

	public function usiaChef() {
		return "$this->usia";
	}

	public function tugasChef() {
		return "$this->tugas";
	}
}

$chef = new Chef();
$chef->nama = "Nama seorang chef ini adalah Fulan bin Fulan.";
$chef->alamat = "Alamat seorang chef ini adalah di Jalan buah batu bandung.";
$chef->tinggi = "Tinggi seorang chef ini adalah 167cm.";
$chef->usia = "Usia seorang chef ini adalah 21 tahun.";
$chef->tugas = "Tugas seorang chef ini adalah yang memiliki kreatif menu dan mempengaruhi dapur suatu restoran.";

echo $chef->namaChef();
echo "<br>";
echo $chef->alamatChef();
echo "<br>";
echo $chef->tinggiChef();
echo "<br>";
echo $chef->usiaChef();
echo "<br>";
echo $chef->tugasChef();
echo "<br><br>";

?>