<?php include "chef.php"; ?>

<?php

class CookHelper extends Chef {

	public $nama,
	  	   $alamat,
	  	   $tinggi,
	  	   $usia,
	  	   $shift;

	public function namaCookHelper() {
		return "Nama cook helper ini adalah Rahmat.";
	}

	public function alamatCookHelper() {
		return "Alamat cook helper ini adalah di Sumedang.";
	}

	public function usiaCookHelper() {
		return "Usia cookhelper ini adalah 21 tahun.";
	}

	public function shiftPertukaranPagi() {
		return "Shift pertukaran pagi cook helper ini seminggu kedepan.";
	}

	public function shiftPertukaranSore() {
		return "Shift pertukaran sore cook helper ini 2 minggu kedepan.";
	}
}

$cookhelper = new CookHelper();
echo $cookhelper->namaCookHelper();
echo "<br>";
echo $chef->alamatChef();
echo "<br>";
echo $cookhelper->shiftPertukaranPagi();
echo "<br>";
echo $chef->tugasChef();
echo "<br>";
echo $cookhelper->shiftPertukaranSore();

?>