<?php 

class MembuatMinuman {

	public $cara_membuat = "cara_membuat",
		   $bahan = "bahan",
		   $biaya = "biaya",
		   $pekerja = "pekerja",
		   $wadah = "wadah";

	public function caraMembuatMinuman() {
		return "$this->cara_membuat";
	}

	public function bahanMembuatMinuman() {
		return "$this->bahan";
	}

	public function biayaMembuatMinuman() {
		return "$this->biaya";
	}

	public function pekerjaMembuatMinuman() {
		return "$this->pekerja";
	}

	public function wadahMembuatMinuman() {
		return "$this->wadah";
	}
}

$minuman = new MembuatMinuman();
$minuman->cara_membuat = "Cara membuat minuman adalah dengan cara diblender, dicampur es batu, dan buah-buahan.";
$minuman->bahan = "Bahan yang dibutuhkan untuk membuat minuman adalah gula, buah-buahan, susu, seres, toping.";
$minuman->biaya = "Biaya yang dibutuhkan untuk membuat minuman adalah 500 ribu";
$minuman->pekerja = "Pekerja untuk membuat minuman adalah pedagang jus.";
$minuman->wadah = "Wadah yang digunakan untuk membuat minuman adalah blender, gelas, mangkok.";

echo $minuman->caraMembuatMinuman();
echo "<br>";
echo $minuman->bahanMembuatMinuman();
echo "<br>";
echo $minuman->biayaMembuatMinuman();
echo "<br>";
echo $minuman->pekerjaMembuatMinuman();
echo "<br>";
echo $minuman->wadahMembuatMinuman();
echo "<br><br>";

?>