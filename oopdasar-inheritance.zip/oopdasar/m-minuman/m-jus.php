<?php include "m-minuman.php"; ?>

<?php 

class membuatJus extends MembuatMinuman {

	public $cara_membuat,
		   $bahan,
		   $biaya,
		   $pekerja,
		   $wadah;

	public function caraMembuatJus() {
		return "Cara membuat jus adalah dengan cara diblender.";
	}

	public function bahanMinimal() {
		return "Minimal bahan membuat jus adalah buah, es, dan air.";
	}

	public function bahanMaksimal() {
		return "Maksimal bahan membuat jus adalah buah, es, air, susu, dan ceres.";
	}

	public function minimalWadah() {
		return "Minimal wadah yang diperlukan adalah blender.";
	}

	public function maksimalWadah() {
		return "Maksimal wadah yang diperlukan adalah blender, gelas, mangkok.";
	}

	public function minimalPekerja() {
		return "Minimal pekerja untuk membuat jus adalah 1 orang.";
	}
}

$jus = new membuatJus();
echo $jus->caraMembuatJus();
echo "<br>";
echo $minuman->biayaMembuatMinuman();
echo "<br>";
echo $jus->minimalWadah();
echo "<br>";
echo $minuman->pekerjaMembuatMinuman();
echo "<br>";
echo $jus->maksimalWadah();

?>