<?php include "minuman.php"; ?>

<?php 

class Sirup extends Minuman {

	public $nama,
	   	   $rasa,
	   	   $cara_membuat,
	   	   $harga,
	   	   $warna;

	public function namaMinuman() {
		return "Nama minuman ini adalah Sirup";
	}

	public function rasaSirup() {
		return "Rasa sirup ini adalah cocopandan";
	}

	public function hargaSirup() {
		return "Harga 1 botol sirup adalah 12 ribu";
	}

	public function warnaMerah() {
		return "Warna merah adalah rasa cocopandan";
	}

	public function warnaHijau() {
		return "Warna hijau adalah rasa melon";
	}
}

$sirup = new Sirup();
echo $sirup->namaMinuman();
echo "<br>";
echo $minuman->menuMinuman();
echo "<br>";
echo $sirup->hargaSirup();
echo "<br>";
echo $minuman->caraMembuatMinuman();
echo "<br>";
echo $sirup->warnaMerah();
?>