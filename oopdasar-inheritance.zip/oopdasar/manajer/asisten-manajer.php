<?php include "manajer-restoran.php"; ?>

<?php 

class AsistenManajer extends ManajerRestoran {

	public $nama,
		   $alamat,
		   $tinggi,
		   $usia,
		   $shift;

	public function namaAsistenManajer() {
		return "Nama seorang asisten ini adalah Asmawi";
	}

	public function tinggiAsistenmanajer() {
		return "Tinggi seorang asisten ini adalah 178cm";
	}

	public function usiaMinimal() {
		return "Usia minimal seorang asisten adalah 24 tahun";
	}

	public function usiaMaksimal() {
		return "Usia maksimal seorang asisten adalah 25 tahun";
	}
}


$asisten = new AsistenManajer();
echo $asisten->namaAsistenManajer();
echo "<br>";
echo $manajer->tinggimanajer();
echo "<br>";
echo $asisten->usiaMinimal();
echo "<br>";
echo $manajer->tugasmanajer();
echo "<br>";
echo $asisten->usiaMaksimal();

?>