<?php 

class ManajerRestoran {

	public $nama = "nama",
		   $alamat = "alamat",
		   $tinggi = "tinggi",
		   $usia = "usia",
		   $tugas = "tugas";

	public function namaManajer() {
		return "$this->nama";
	}

	public function alamatManajer() {
		return "$this->alamat";
	}

	public function tinggiManajer() {
		return "$this->tinggi";
	}

	public function usiaManajer() {
		return "$this->usia";
	}

	public function tugasManajer() {
		return "$this->tugas";
	}
}

$manajer = new ManajerRestoran();
$manajer->nama = "Nama seorang pelayan ini adalah Fulan.";
$manajer->alamat = "Alamat seorang manajer ini adalah di Jalan situ patenggang.";
$manajer->tinggi = "Tinggi seorang manajer ini adalah 175cm.";
$manajer->usia = "Usia seorang manajer ini adalah 20 tahun.";
$manajer->tugas = "Tugas seorang manajer ini adalah sebagai kepala operasional restoran, mengawasi daily operasional di restoran.";

echo $manajer->namaManajer();
echo "<br>";
echo $manajer->alamatManajer();
echo "<br>";
echo $manajer->tinggiManajer();
echo "<br>";
echo $manajer->usiaManajer();
echo "<br>";
echo $manajer->tugasManajer();
echo "<br><br>";

?>