<?php include "supervisorkasir.php"; ?>
<?php 

class Kasir extends SupervisorKasir {

	public $nama,
		   $alamat,
		   $tinggi,
		   $shift,
		   $tugas;

	public function namaKaryawanKasir() {
		return "Karyawan kasir ini namanya adalah Fulan bin Fulan";
	}

	public function alamatKaryawanKasir() {
		return "Alamat karyawan kasir ini adalah di Cianjur";
	}

	public function tinggiKaryawanKasir() {
		return "Tinggi karyawan kasir ini adalah 178cm.";
	}

	public function shiftPagiKaryawan() {
		return "Shift pagi karyawan kasir ini adalah jam 8 pagi.";
	}

	public function shiftSoreKaryawan() {
		return "Shift sore karyawan kasir ini adalah jam 4 sore.";
	}
}

$kasir = new Kasir();
echo $kasir->namaKaryawanKasir();
echo "<br>";
echo $supervisor->alamatSupervisorKasir(); 
echo "<br>";
echo $kasir->shiftPagiKaryawan();
echo "<br>";
echo $supervisor->tugasSupervisorKasir();
echo "<br>";
echo $kasir->shiftSoreKaryawan();

?>