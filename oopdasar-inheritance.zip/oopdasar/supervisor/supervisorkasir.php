<?php 

class SupervisorKasir {

	public $nama = "nama",
		   $alamat = "alamat",
		   $tinggi = "tinggi",
		   $usia = "usia",
		   $tugas = "tugas";

	public function namaSupervisorKasir() {
		return "Nama seorang supervisor kasir ini adalah Fulanah bin Fulan.";
	}

	public function alamatSupervisorKasir() {
		return "Alamat seorang supervisor kasir ini adalah di Jalan buah batu";
	}

	public function tinggiSupervisorKasir() {
		return "Tinggi seorang supervisor kasir ini adalah 165cm.";
	}

	public function usiaSupervisorKasir() {
		return "Usia seorang supervisor kasir ini adalah 25 tahun.";
	}

	public function tugasSupervisorKasir() {
		return "Tugas seorang supervisor kasir ini adalah mengontrol kinerja seorang kasir, dan memberi arahan.";
	}
}

$supervisor = new SupervisorKasir();
echo $supervisor->namaSupervisorKasir();
echo "<br>";
echo $supervisor->alamatSupervisorKasir();
echo "<br>";
echo $supervisor->tinggiSupervisorKasir();
echo "<br>";
echo $supervisor->usiaSupervisorKasir();
echo "<br>";
echo $supervisor->tugasSupervisorKasir();
echo "<br><br>";

?>