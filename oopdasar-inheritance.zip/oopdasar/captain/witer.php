<?php include "captainwriter.php"; ?>
<?php 

class Writer extends CaptainWiter {

	public $nama,
		   $alamat,
		   $tinggi,
		   $usia,
		   $shift;

	public function namaWiter() {
		return "Nama witer adalah Asep";
	}

	public function alamatWiter() {
		return "Alamat witer ini adalah di Bandung";
	}

 	public function tinggiMinimal() {
 		return "Tinggi minimal seorang witer adalah 165cm";
 	}

 	public function tinggiMaksimal() {
 		return "Tinggi maksimal seorang asisten adalah 175cm";
 	} 
}

$asisten = new Witer();
echo $witer->namaWiter();
echo "<br>";
echo $captainwiter->alamatCaptainWiter();
echo "<br>";
echo $witer->tinggiMinimal();
echo "<br>";
echo $captainwiter->tugasCaptainWiter();
echo "<br>";
echo $witer->tinggiMaksimal();

?>