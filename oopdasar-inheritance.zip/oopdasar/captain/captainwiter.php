<?php 

class CaptainWiter {

	public $nama = "nama",
		   $alamat = "alamat",
		   $tinggi = "tinggi",
		   $usia = "usia",
		   $tugas = "tugas";

	public function namaCaptainWiter() {
		return "$this->nama";
	}

	public function alamatCaptainWiter() {
		return "$this->alamat";
	}

	public function tinggiCaptainWiter() {
		return "$this->tinggi";
	}

	public function usiaCaptainWiter() {
		return "$this->usia";
	}

	public function tugasCaptainWiter() {
		return "$this->tugas";
	}
}

$captainwiter = new CaptainWiter();
$captainwiter->nama = "Nama seorang captain witer ini adalah Fulanah.";
$captainwiter->alamat = "Alamat seorang captain witer ini adalah di Jalan situ batu.";
$captainwiter->tinggi = "Tinggi seorang captain witer ini adalah 180cm.";
$captainwiter->usia = "Usia seorang captain witer ini adalah 22 tahun.";
$captainwiter->tugas = "Tugas seorang captain witer ini adalah sebagai wakil supervisor dalam penanganan operasional.";

echo $captainwiter->namaCaptainWiter();
echo "<br>";
echo $captainwiter->alamatCaptainWiter();
echo "<br>";
echo $captainwiter->tinggiCaptainWiter();
echo "<br>";
echo $captainwiter->usiaCaptainWiter();
echo "<br>";
echo $captainwiter->tugasCaptainWiter();
echo "<br><br>";

?>