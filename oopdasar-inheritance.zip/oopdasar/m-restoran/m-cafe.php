<?php include "m-restoran.php"; ?>

<?php 

class membangunCafe extends MembangunRestoran {

	public $cara_membangun,
		   $bahan,
		   $biaya,
		   $pekerja,
		   $lokasi;

	public function caraMembangunCafe() {
		return "Cara membangun cafe adalah dirancang oleh seorang artitek dan dibangun oleh para pekerja bangunan.";
	}

	public function bahanMembangunCafe() {
		return "Bahan untuk membangun cafe adalah semen, pasir, batu bata";
	}

	public function minimalPekerja() {
		return "Minimal pekerja untuk membangun sebuah cafe adalah 3 orang";
	}

	public function maksimalPekerja() {
		return "Maksimal pekerja untuk membangun sebuah cafe adalah 6 orang";
	}

	public function lokasiMembangunCafe() {
		return "Lokasi untuk membangun sebuah cafe adalah di suatu lokasi di pinggir jalan yang lokasinya strategis";
	}

}

$cafe = new membangunCafe();
echo $cafe->caraMembangunCafe();
echo "<br>";
echo $restoran->biayaMembangunRestoran();
echo "<br>";
echo $cafe->minimalPekerja();
echo "<br>";
echo $restoran->bahanMembangunRestoran();
echo "<br>";
echo $cafe->maksimalPekerja();

?>