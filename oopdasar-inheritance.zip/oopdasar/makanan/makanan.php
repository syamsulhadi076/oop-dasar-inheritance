<?php 

class Makanan {

	public $nama = "nama",
		   $bentuk = "bentuk",
		   $rasa = "rasa",
		   $cara_membuat = "cara_membuat",
		   $harga = "harga";

	public function namaMakanan() {
		return "$this->nama";
	}

	public function bentukMakanan() {
		return "$this->bentuk";
	}

	public function rasaMakanan() {
		return "$this->rasa";
	}

	public function caraMembuatMakanan() {
		return "$this->cara_membuat";
	}

	public function hargaMakanan() {
		return "$this->harga";
	}

}

$makanan = new Makanan();
$makanan->nama = "Makanan ini adalah Bakso.";
$makanan->bentuk = "Bakso ini bentuknya Bulat.";
$makanan->rasa = "Rasa bakso adalah asin manis pedas dan gurih.";
$makanan->cara_membuat = "Cara membuat bakso adalah dibentuk bulat dengan menggunakan tepung dan daging.";
$makanan->harga = "Bakso seporsi harganya 10.000.";

echo $makanan->namaMakanan();
echo "<br>";
echo $makanan->bentukMakanan();
echo "<br>";
echo $makanan->rasaMakanan();
echo "<br>";
echo $makanan->caraMembuatMakanan();
echo "<br>";
echo $makanan->hargaMakanan();
echo "<br><br>";

?>