<?php include "makanan.php"; ?>

<?php 

class Cemilan extends Makanan{

	public $nama,
	   	   $bentuk,
	   	   $rasa,
	   	   $cara_membuat,
	   	   $harga;

	public function namaCemilan() {
		return "Nama cemilan ini adalah keripik";
	}

	public function bentukCemilan() {
		return "Bentuk cemilan ini adalah panjang, tipis, dan lebar";
	}

	public function rasaOriginal() {
		return "Cemilan ini mempunyai rasa original yaitu asin dan gurih";
	}

	public function rasaBalado() {
		return "Cemilan ini juga mempunyai rasa balado yaitu pedas";
	}

	public function hargaCemilan() {
		return "Harga sebungkus cemilan ini adalah 10.0000";
	}
}

$cemilan = new Cemilan();
echo $cemilan->namaCemilan();
echo "<br>";
echo $makanan->caraMembuatMakanan();
echo "<br>";
echo $cemilan->bentukCemilan();
echo "<br>";
echo $makanan->hargaMakanan();
echo "<br>";
echo $cemilan->rasaBalado();

?>