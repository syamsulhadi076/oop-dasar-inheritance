<?php include "m-makanan.php"; ?>

<?php 

class membuatCemilan extends MembuatMakanan {

	public $cara_membuat,
		   $bahan,
		   $biaya,
		   $pekerja,
		   $wadah;

	public function caraMembuatCemilan() {
		return "Cara membuat cemilan tempe adalah digoreng";
	}

	public function bahanMinimal() {
		return "Bahan minimal membuat cemilan adalah tempe, minyak, tepung";
	}

	public function minimalPekerja() {
		return "Minimum pekerja membuat cemilan adalah 1 orang";
	}

	public function maksimalPekerja() {
		return "Maksimal pekerja membuat cemilan adalah 5 orang";
	}
}

$cemilan = new membuatCemilan();
echo $cemilan->caraMembuatCemilan();
echo "<br>";
echo $makanan->bahanMembuatMakanan();
echo "<br>";
echo $cemilan->minimalPekerja();
echo "<br>";
echo $makanan->biayaMembuatMakanan();
echo "<br>";
echo $cemilan->maksimalPekerja();

?>