<?php 

class Restoran {

	public $nama,
		   $tipe,
		   $menu,
		   $lokasi,
		   $pemilik;

	public function namaRestoran() {
		return "Nama restoran ini adalah Altierest";
	}

	public function tipeRestoran() {
		return "Tipe restoran ini adalah restoran makanan daerah";
	}

	public function menuRestoran() {
		return "Menu restoran ini adalah berbagai macam masakan daerah Indonesia";
	}

	public function lokasiRestoran() {
		return "Lokasi restoran ini adalah di negara Belanda";
	}

	public function pemilikRestoran() {
		return "Pemilik restoran ini adalah Samsul Hadi";
	}
}

$restoran = new Restoran();
echo $restoran->namaRestoran();
echo "<br>";
echo $restoran->tipeRestoran();
echo "<br>";
echo $restoran->menuRestoran();
echo "<br>";
echo $restoran->lokasiRestoran();
echo "<br>";
echo $restoran->pemilikRestoran();
echo "<br><br>";

?>