<?php include "restoran.php"; ?>
<?php 

class Cafe extends Restoran{

	public $nama,
		   $jadwal,
		   $menu,
		   $lokasi,
		   $pemilik;

	public function namaCafe() {
		return "Nama cafe ini adalah Altie Cafe";
	}

	public function jadwalBuka() {
		return "Jadwal buka cafe ini adalah jam 9 pagi";
	}

	public function jadwalTutup() {
		return "Jadwal tutup cafe ini adalah jam 10 malam";
	}

	public function menuCafe() {
		return "Menu di cafe ini biasanya menyediakan roti bakar, milkshake, dan stik";
	}

	public function lokasiCafe() {
		return "Lokasi cafe ini adalah di negara Indonesia";
	}

}

$cafe = new Cafe();
echo $cafe->namaCafe();
echo "<br>";
echo $restoran->tipeRestoran();
echo "<br>";
echo $cafe->menuCafe();
echo "<br>";
echo $restoran->lokasiRestoran();
echo "<br>";
echo $cafe->jadwalBuka();
?>