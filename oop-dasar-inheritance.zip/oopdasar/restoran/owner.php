<?php include "restoran.php"; ?>

<?php 

class Owner extends Restoran {

	public $wewenang = "wewenang";
	public $jabatan = "jabatan";
	public $pemilik_restoran = "pemilik_restoran";
	public $atasan_manager = "atasan_manager";
	public $kendali_restoran = "kendali_restoran";

	public function membuatWewenang() {
		return "$this->wewenang";
	}

	public function menaikanJabatan() {
		return "$this->jabatan";
	}

	public function memberikanPerintah() {
		return "$this->pemilik_restoran";
	}

	public function menurunkanJabatan() {
		return "$this->atasan_manager";
	}

	public function menyetujuiPendapat() {
		return "$this->kendali_restoran";
	}
}

$owner = new Owner();
$owner1 = new Owner();
$owner2 = new Owner();
$owner3 = new Owner();
$owner4 = new Owner();

$owner->wewenang = "Owner restoran membuat wewenang restoran tidak boleh telat masuk";
$owner1->jabatan = "Owner pun seseorang yang menaikan jabatan para karyawan";
$owner2->pemilik_restoran = "Sebagai pemilik restoran, owner berhak memberikan kepada manager, asisten, dan para karyawannya";
$owner3->atasan_manager = "Sebagai atasan manager yang sering kali disebut owner, juga mempunyai wewenang untuk menurunkan jabatan karyawannya";
$owner4->kendali_restoran = "Jika manager, asisten, atau supervisor mempunyai usulan, owner juga bisa menyetujui pendapat mereka";

echo $owner->membuatWewenang();
echo "<br>";
echo $restoran->memberiNamaRestoran();
echo "<br>";
echo $owner1->menaikanJabatan();
echo "<br>";
echo $restoran2->merekrutKaryawan();
echo "<br>";
echo $owner3->menurunkanJabatan();

?>