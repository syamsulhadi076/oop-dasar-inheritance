<?php include "restoran.php"; ?>

<?php 

class Asisten extends Restoran {

	public $pengganti_manager = "pengganti_manager";
	public $bawahan_manager = "bawahan_manager";
	public $kinerja_asisten = "kinerja_asisten";
	public $sistem_kerja = "sistem_kerja";
	public $tugas_asisten = "tugas_asisten";

	public function membantuManager() {
		return "$this->pengganti_manager";
	}

	public function membuatSistemKerja() {
		return "$this->sistem_kerja";
	}

	public function meningkatkanKinerjaPribadi() {
		return "$this->kinerja_asisten";
	}

	public function melaksanakanTugas() {
		return "$this->tugas_asisten";
	}

	public function menjabatiPosisi() {
		return "$this->bawahan_manager";
	}
}

$asisten = new Asisten();
$asisten1 = new Asisten();
$asisten2 = new Asisten();
$asisten3 = new Asisten();
$asisten4 = new Asisten();

$asisten->pengganti_manager = "Sebagai asisten, ketika manager tidak hadir maka tugas manager digantikan oleh asisten manager";
$asisten1->sistem_kerja = "Dan sebagai seorang asisten, salah satu tugasnya adalah membuat sistem kerja";
$asisten2->kinerja_asisten = "Maka asisten juga dituntut untuk meningkatkan kinerja dirinya sendiri secara pribadi";
$asisten3->tugas_asisten = "Dan yang terpenting, seorang asisten manager harus melaksanakan tugasnya dengan baik dan benar";
$asisten4->bawahan_manager = "Maka dari itu sebagai bawahan manager yang menjabati posisi asisten, asisten harus bisa bekerja sama dengan seorang manager";

echo $asisten->membantuManager();
echo "<br>";
echo $restoran3->menentukanLokasi();
echo "<br>";
echo $asisten2->meningkatkanKinerjaPribadi();
echo "<br>";
echo $restoran4->menanyakanPemilik();
echo "<br>";
echo $asisten4->menjabatiPosisi();

?>