<?php include "restoran.php"; ?>

<?php 

class Manager extends Restoran {

	public $bawahan_owner = "bawahan_owner";
	public $pengganti_owner = "pengganti_owner";
	public $pengkoordinir_supervisor = "pengkoordinir_supervisor";
	public $pengawas_supervisor = "pengawas_supervisor";
	public $kendali_supervisor = "kendali_supervisor";

	public function mengkoordinirSupervisor() {
		return "$this->pengkoordinir_supervisor";
	}

	public function tingkatkanKinerja() {
		return "$this->kendali_supervisor";
	}

	public function pengawasSupervisor() {
		return "$this->pengawas_supervisor";
	}

	public function ambilKendali() {
		return "$this->pengganti_owner";
	}

	public function meningkatkanKinerjaSupervisor() {
		return "$this->bawahan_owner";
	}
}

$manager = new Manager();
$manager1 = new Manager();
$manager2 = new Manager();
$manager3 = new Manager();
$manager4 = new Manager();

$manager->pengkoordinir_supervisor = "Seorang manager bertugas mengkordinir supervisor";
$manager1->kendali_supervisor = "Seorang manager mengendalikan supervisor untuk meningkatkan kinerja";
$manager2->bawahan_owner = "Seorang supervisor ditingkatkan kinerjanya oleh bawahan owner yaitu manager";
$manager3->pengganti_owner = "Ketika owner tidak hadir di restoran maka digantikan oleh manager";
$manager4->pengawas_supervisor = "Dan salah satunya manager harus mengawasi supervisor";

echo $manager->mengkoordinirSupervisor();
echo "<br>";
echo $restoran->menuTerbaru();
echo "<br>";
echo $manager1->tingkatkanKinerja();
echo "<br>";
echo $restoran->jamTutup();
echo "<br>";
echo $manager3->ambilKendali();

?>