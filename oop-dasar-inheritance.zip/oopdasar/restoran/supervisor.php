<?php include "restoran.php"; ?>

<?php 

class Supervisor extends Restoran {

	public $bawahan_asisten;
	public $pengawas_karyawan;
    public $atasan_karyawan;
	public $jadwal_karyawan;
	public $pengusul_jumlah_karyawan;

	public function MengecekKehadiranKaryawan() {
		return "$this->bawahan_asisten";
	}

	public function MembuatJadwalKerjaKaryawan() {
		return "$this->jadwal_karyawan";
	}

	public function MengusulkanPenambahanKaryawan() {
		return "$this->pengusul_jumlah_karyawan";
	}

	public function MengecekDaftarMenu() {
		return "$this->atasan_karyawan";
	}

	public function MenanganiKelancaranOperasional() {
		return "$this->pengawas_karyawan";
	}
}

$supervisor = new Supervisor();
$supervisor1 = new Supervisor();
$supervisor2 = new Supervisor();
$supervisor3 = new Supervisor();
$supervisor4 = new Supervisor();

$supervisor->bawahan_asisten = "Sebagai bawahn asisten, supervisor mempunyai tugas mengecek kehadiran karyawan";
$supervisor1->jadwal_karyawan = "Jadwal kerja karyawan dibuat oleh supervisor";
$supervisor2->pengusul_jumlah_karyawan = "Jika restoran membutuhkan karyawan tambahan, supervisor bisa mengusulkan kepada atasan";
$supervisor3->atasan_karyawan = "Sebagai atasan karyawan, supervisor juga mempunyai tugas mengecek daftar menu restoran";
$supervisor4->pengawas_karyawan = "Sebagai pengawas karyawan, supervisor juga menangani kelancaran operasional";

echo $supervisor->MengecekKehadiranKaryawan();
echo "<br>";
echo $restoran->memberiNamaRestoran();
echo "<br>";
echo $supervisor1->MembuatJadwalKerjaKaryawan();
echo "<br>";
echo $restoran2->merekrutKaryawan();
echo "<br>";
echo $supervisor3->MengusulkanPenambahanKaryawan();

?>