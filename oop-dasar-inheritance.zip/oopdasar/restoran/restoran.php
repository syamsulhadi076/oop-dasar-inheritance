<?php

class Restoran {

	public $nama;
	public $menu;
	public $karyawan;
	public $lokasi;
	public $pemilik;

	public function memberiNamaRestoran() {
		return "$this->nama";
	}

	public function membuatDaftarMenu() {
		return "$this->menu";
	}

	public function merekrutKaryawan() {
		return "$this->karyawan";
	}

	public function menentukanLokasi() {
		return "$this->lokasi";
	}

	public function menanyakanPemilik() {
		return "$this->pemilik";
	}

}

$restoran = new Restoran();
$restoran1 = new Restoran();
$restoran2 = new Restoran();
$restoran3 =  new Restoran();
$restoran4 = new Restoran();

$restoran->nama = "Pemilik restoran ini memberikan nama Altirerest pada restorannya";
$restoran1->menu = "Restoran inipun sangat kreatif karena membuat daftar menu makanan dari sebuah website";
$restoran2->karyawan = "Setelah restoran ini mulai membesar, maka banyak merekrut orang untuk dijadikan karyawan";
$restoran3->lokasi = "Pemilik restoran ini menentukan lokasinya di negara Singapura";
$restoran4->pemilik = "Banyak sekali para pelanggan menanyakan siapa pemiliknya, karena restorannya sangat terkenal";

echo $restoran->memberiNamaRestoran();
echo "<br>";
echo $restoran1->membuatDaftarMenu();
echo "<br>";
echo $restoran2->merekrutKaryawan();
echo "<br>";
echo $restoran3->menentukanLokasi();
echo "<br>";
echo $restoran4->menanyakanPemilik();
echo "<br><br>";

?>