<?php include "restoran.php"; ?>

<?php 

class Captain extends Restoran {

	public $bawahan_supervisor = "bawahan_supervisor";
	public $atasan_waiter = "atasan_waiter";
	public $wakil_supervisor = "wakil_supervisor";
	public $kendali_waiter = "kendali_waiter";
	public $tugas = "tugas";

	public function CekPersediaanBarang() {
		return "$this->tugas";
	}

	public function CekKebersihanSeluruhRestoran() {
		return "$this->atasan_waiter";
	}

	public function CekStandarKualitasMakanan() {
		return "$this->bawahan_supervisor";
	}

	public function meningkatkanKinerjaWaiter() {
		return "$this->kendali_waiter";
	}

	public function MemberikanLaporanPenilaianKaryawan() {
		return "$this->wakil_supervisor";
	}
}

$captain = new Captain();
$captain1 = new Captain();
$captain2 = new Captain();
$captain3 = new Captain();
$captain4 = new Captain();

$captain->tugas = "Salah satu tugas captain waiter adalah mengecek persediaan barang";
$captain1->atasan_waiter = "Sebagai atasan waiter, captain juga harus mengecek kebersihan seluruh restoran";
$captain2->bawahan_supervisor = "Dan sebagai bawahan dari supervisor, captain pun harus mengecek standar kualitas makanan";
$captain3->kendali_waiter = "Sebagai seseorang yang punya kendali waiter, harus meningkatkan kinerja waiter";
$captain4->wakil_supervisor = "Captain waiter adalah wakil supervisor, dan mempunyai tugas memberikan laporan penilaian karyawan";

echo $captain->CekPersediaanBarang();
echo "<br>";
echo $restoran2->merekrutKaryawan();
echo "<br>";
echo $captain1->CekKebersihanSeluruhRestoran();
echo "<br>";
echo $restoran3->menentukanLokasi();
echo "<br>";
echo $captain->CekPersediaanBarang();

?>