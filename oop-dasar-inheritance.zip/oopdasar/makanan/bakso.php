<?php include "makanan.php"; ?>

<?php 

class Bakso extends Makanan {

	public $daging = "daging";
	public $toge = "toge";
	public $mie_kuning = "mie_kuning";
	public $bihun = "bihun";
	public $seledri = "seledri";

	public function merebusToge() {
		return "$this->toge";
	}

	public function membeliBakso() {
		return "$this->mie_kuning";
	}

	public function membuatBakso() {
		return "$this->daging";
	}

	public function memasukanBihun() {
		return "$this->bihun";
	}

	public function menaburkanSeledri() {
		return "$this->seledri";
	}
}

$bakso = new Bakso();
$bakso1 = new Bakso();
$bakso2 = new Bakso();
$bakso3 = new Bakso();
$bakso4 = new Bakso();

$bakso->toge = "Rebus toge setengah matang sebelum dimasukan ke mangkok";
$bakso1->mie_kuning = "Para penggemar bakso sering membeli bakso dengan mencampur mie kuning";
$bakso2->daging = "Cara membuat bakso adalah mencampur adonan bakso dengan daging sapi yang sudah digiling";
$bakso3->bihun = "Kemudian masukan bihun yang sudah direbus ke mangkok";
$bakso4->seledri = "Setelah bakso, mie dan toge dimasukan ke mangkok, taburkan seledri di atasnya";

echo $bakso->merebusToge();
echo "<br>";
echo $makanan->mengenyangkanPerut();
echo "<br>";
echo $bakso1->membeliBakso();
echo "<br>";
echo $makanan1->menghasilkanUang();
echo "<br>";
echo $bakso3->memasukanBihun();

?>