<?php include "makanan.php"; ?>

<?php 

class Karedok extends Makanan {

	public $timun = "timun";
	public $kol = "kol";
	public $kacang_tanah = "kacang_tanah";
	public $labu = "labu";
	public $kacang_panjang = "kacang_panjang";

	public function membuatBumbu() {
		return "$this->kacang_tanah";
	}

	public function membeliBahan() {
		return "$this->timun";
	}

	public function caraMembuatKaredok() {
		return "$this->labu";
	}

	public function mengadukBumbu() {
		return "$this->kacang_panjang";
	}

	public function memotongBahan() {
		return "$this->kol";
	}
}

$karedok = new Karedok();
$karedok1 = new Karedok();
$karedok2 = new Karedok();
$karedok3 = new Karedok();
$karedok4 = new Karedok();

$karedok->kacang_tanah = "Buatlah bumbu karedok dengan cara mengulek kacang tanah yang sudah digoreng sampai halus";
$karedok1->timun = "Membeli bahan karedok salah satunya adalah timun";
$karedok2->labu = "Cara membuat karedok adalah mencampurkan bumbu dengan bahan-bahan, salah satunya dengan labu";
$karedok3->kacang_panjang = "Aduklah bumbu yang sudah jadi dengan bahan kol, timun, dan kacang panjang";
$karedok4->kol = "Potonglah bahan-bahan menjadi kecil-kecil, dan jangan lupa potong kolnya";


echo $karedok->membuatBumbu();
echo "<br>";
echo $makanan1->menghasilkanUang();
echo "<br>";
echo $karedok1->membeliBahan();
echo "<br>";
echo $makanan2->MenjadikanusahaSampingan();
echo "<br>";
echo $karedok2->caraMembuatKaredok();

?>