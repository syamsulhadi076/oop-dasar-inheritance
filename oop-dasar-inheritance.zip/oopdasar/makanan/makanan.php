<?php 

class Makanan {

	public $harga = "harga";
	public $rasa = "rasa";
	public $bentuk = "bentuk";
	public $warna = "warna";
	public $cara_membuat = "cara_membuat";

	public function mengenyangkanPerut() {
		return "$this->bentuk";
	}

	public function menghasilkanUang() {
		return "$this->harga";
	}

	public function MenjadikanUsahaSampingan() {
		return "$this->cara_membuat";
	}

	public function MenjadikanlaukPaukMakan() {
		return "$this->rasa";
	}

	public function MembuatpeluangUsaha() {
		return "$this->bentuk";
	} 

}

$makanan = new Makanan();
$makanan1 = new Makanan();
$makanan2 = new Makanan();
$makanan3 = new Makanan();
$makanan4 = new Makanan();

$makanan->bentuk = "Makanan bisa mengenyangkan perut karena bentuknya yang beraneka macam";
$makanan1->harga = "Makanan juga bisa menghasilkan uang karena harganya cukup terjangkau dan beragam";
$makanan2->cara_membuat = "Bisa dijadikan usaha sampingan karena cara membuatnya cukup mudah";
$makanan3->rasa = "Juga bisa dijadikan sebagai lauk pauk makan karena rasanya yang enak";
$makanan4->bentuk = "Makanan juga bisa dijadikan peluang usaha karena mudah dibentuk";

echo $makanan->mengenyangkanPerut();
echo "<br>";
echo $makanan1->menghasilkanUang();
echo "<br>";
echo $makanan2->MenjadikanUsahaSampingan();
echo "<br>";
echo $makanan3->MenjadikanlaukPaukMakan();
echo "<br>";
echo $makanan4->MembuatpeluangUsaha();
echo "<br><br>";

?>