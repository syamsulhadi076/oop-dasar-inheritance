<?php include "makanan.php"; ?>

<?php 

class Pempek extends Makanan {

	public $tepung = "tepung";
	public $ikan = "ikan";
	public $telur = "telur";
	public $minyak = "minyak";
	public $terigu = "terigu";

	public function mencampurIkan() {
		return "$this->ikan";
	}

	public function mengadukBahan() {
		return "$this->terigu";
	}

	public function membeliPempek() {
		return "$this->telur";
	}

	public function menggorengPempek() {
		return "$this->minyak";
	}

	public function mencampurAdonan() {
		return "$this->tepung";
	}
}

$pempek = new Pempek();
$pempek1 = new Pempek();
$pempek2 = new Pempek();
$pempek3 = new Pempek();
$pempek4 = new Pempek();

$pempek->ikan = "Biasanya adonan pempek dicampur dengan gilingan ikan yang sudah halus";
$pempek1->terigu = "Mengaduk bahan pempek dicampur dengan terigu";
$pempek2->telur = "Pempek banyak pembelinya karena dicampur dengan ikan dan telur";
$pempek3->minyak = "Pempek digoreng didalam minyak yang panas";
$pempek4->tepung = "Campurkan adonan pempek dengan tepung dan terigu";

echo $pempek->mencampurIkan();
echo "<br>";
echo $makanan1->menghasilkanUang();
echo "<br>";
echo $pempek2->membeliPempek();
echo "<br>";
echo $makanan->mengenyangkanPerut();
echo "<br>";
echo $pempek3->menggorengPempek();

?>