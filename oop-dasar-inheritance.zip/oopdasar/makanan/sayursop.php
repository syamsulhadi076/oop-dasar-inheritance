<?php include "makanan.php"; ?>

<?php 

class SayurSop extends Makanan {

	public $kentang = "kentang";
	public $bahan_sop = "bahan_sop";
	public $masako = "masako"; 
	public $ketumbar = "ketumbar";
	public $wortel = "wortel";

	public function MemasakSop() {
		return "$this->kentang";
	}

	public function MenyiapkanBahan() {
		return "$this->bahan_sop";
	}

	public function MembeliBahan() {
		return "$this->wortel";
	}

	public function MembeliBumbu() {
		return "$this->masako";
	}

	public function MeracikBumbu() {
		return "$this->ketumbar";
	}
}

$kentang = new SayurSop();
$ketumbar = new SayurSop();
$masako = new SayurSop();
$wortel = new SayurSop();
$bahan_sop = new SayurSop();

$wortel->wortel = "Membeli bahan sop salah satunya adalah wortel";
$masako->masako = "Membeli bumbu sop salah satunya adalah masako";
$bahan_sop->bahan_sop = "Menyiapkan bahan membuat sop untuk dimasak";
$ketumbar->ketumbar = "Meracik bumbu dengan cara mencampurkan masako dengan ketumbar";
$kentang->kentang = "Memasak sop dengan bahan dan bumbu yang telah dibeli, dan tidak lupa masukan kentang kedalamnya";

echo $wortel->MembeliBahan();
echo "<br>";
echo $masako->MembeliBumbu();
echo "<br>";
echo $bahan_sop->MenyiapkanBahan();
echo "<br>";
echo $ketumbar->MeracikBumbu();
echo "<br>";
echo $kentang->MemasakSop();

?>