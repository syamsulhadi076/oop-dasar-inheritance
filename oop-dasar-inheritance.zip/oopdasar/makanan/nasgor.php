<?php include "makanan.php"; ?>

<?php 

class Nasgor extends Makanan {

	public $ayam = "ayam";
	public $sosis = "sosis";
	public $telur = "telur";
	public $pedas_manis = "pedas_manis";
	public $nasi = "nasi";

	public function mencampurAyam() {
		return "$this->ayam";
	}

	public function menambahkanSosis() {
		return "$this->sosis";
	}

	public function menggorengTelur() {
		return "$this->telur";
	}

	public function membuatRasaNasgor() {
		return "$this->pedas_manis";
	}

	public function memasukanNasi() {
		return "$this->nasi";
	}
}

$nasgor = new Nasgor();
$nasgor1 = new Nasgor();
$nasgor2 = new Nasgor();
$nasgor3 = new Nasgor();
$nasgor4 = new Nasgor();

$nasgor->ayam = "Biasanya memasak nasgor dicampur dengan ayam";
$nasgor1->sosis = "Lalu ditambah dengan sosis";
$nasgor2->telur = "Tapi sebelum memasukan nasi nya, telur digoreng terlebih dahulu";
$nasgor3->pedas_manis = "Rasa nasgor bisa dibuat pedas manis dengan kecap dan sambal";
$nasgor4->nasi = "Setelah memasak telur, masukan nasi kedalam panci";

echo $nasgor->mencampurAyam();
echo "<br>";
echo $makanan->mengenyangkanPerut();
echo "<br>";
echo $nasgor2->menggorengTelur();
echo "<br>";
echo $makanan4->MembuatpeluangUsaha();
echo "<br>";
echo $nasgor4->memasukanNasi();

?>